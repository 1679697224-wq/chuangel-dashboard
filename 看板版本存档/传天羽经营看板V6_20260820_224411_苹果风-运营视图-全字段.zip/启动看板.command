#!/bin/bash
cd "$(dirname "$0")"
echo "传天羽经营看板 V6 启动中 -> http://127.0.0.1:8003"
/usr/bin/python3 app.py
