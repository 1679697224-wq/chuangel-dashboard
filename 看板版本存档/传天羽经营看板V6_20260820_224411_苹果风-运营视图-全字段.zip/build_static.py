# -*- coding: utf-8 -*-
"""生成静态可部署版 -> deploy/（可直接上传到 GitHub Pages / Cloudflare Pages / 腾讯云COS / 阿里云OSS 等任意静态托管）
运行: python3 build_static.py
"""
import json, shutil
from pathlib import Path

BASE = Path(__file__).resolve().parent
DEPLOY = BASE / "deploy"

data = json.loads((BASE / "data.json").read_text(encoding="utf-8"))
html = (BASE / "templates" / "index.html").read_text(encoding="utf-8")
inject = "<script>window.DASH_DATA=" + json.dumps(data, ensure_ascii=False) + ";</script>"
assert "</head>" in html
html = html.replace("</head>", inject + "</head>", 1)

DEPLOY.mkdir(exist_ok=True)
(DEPLOY / "index.html").write_text(html, encoding="utf-8")
static = DEPLOY / "static"
static.mkdir(exist_ok=True)
shutil.copy2(BASE / "static" / "command-center.css", static / "command-center.css")
(DEPLOY / "README.txt").write_text(
    "传天羽经营看板 V6 静态版（数据内嵌，虚拟演示）\n部署方式：把本目录内容上传到任意静态网站托管即可。\n重新生成：运行 python3 build_static.py（先确保 data.json 已更新）。",
    encoding="utf-8")
print("deploy/ generated:", len(html), "bytes html")
