#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""传天羽经营看板 V6 · 本地服务（零第三方依赖）
运行: python3 app.py  ->  http://127.0.0.1:8003
接口: /           看板页面
      /api/data   data.json（前端唯一数据源）
      /api/summary?kind=home|company|apr|apple|shure|inventory  规则生成经营总结
      /api/ai     POST {"q":"问题"}：优先本地 ollama，不可用则回落规则总结
"""
import json
import mimetypes
import os
import sys
import urllib.error
import urllib.request
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

BASE = Path(__file__).resolve().parent
PORT = int(os.environ.get("PORT", "8003"))
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "qwen3:8b"
OLLAMA_TIMEOUT = 2.5


def load_data():
    return json.loads((BASE / "data.json").read_text(encoding="utf-8"))


def wan(x, nd=1):
    try:
        return round(float(x or 0), nd)
    except (TypeError, ValueError):
        return 0


def pct(x, nd=1):
    try:
        return round(float(x or 0) * 100, nd)
    except (TypeError, ValueError):
        return 0


def fmt_w(x):
    return str(wan(x))


def build_summary(kind="home"):
    d = load_data()
    c = d["company"]
    apr = d["apr"]["total"]
    apple = d["apple_ec"]["total"]
    shure = d["shure_ec"]["total"]
    lines = []
    if kind in ("home", "company"):
        lines.append(f"【公司总览】8月截至{d['asof'][-2:]}日：累计销售额{fmt_w(c['sales'])}万，目标{fmt_w(c['task'])}万，达成率{pct(c['sales_rate'])}%（时间进度{pct(c['time_progress'])}%，差{c['gap_pp']}pp）。")
        lines.append(f"预计月末达成{fmt_w(c['forecast_month_end'])}万，预测达成率{pct(c['forecast_rate'])}%。")
        lines.append(f"毛利{fmt_w(c['gross_profit'])}万（毛利率{pct(c['gross_rate'])}%），费用合计{fmt_w(c['fees'])}万，店铺利润合计{fmt_w(c['profit'])}万（演示口径，真实口径待财务确认）。")
        plates = [p for p in c["plates"] if p.get("sales", 0) > 0]
        if plates:
            top = max(plates, key=lambda p: p["sales"])
            lines.append(f"最大贡献板块：{top['name']}（{fmt_w(top['sales'])}万，占比{pct(top['sales'] / c['sales'])}%）。")
        else:
            lines.append("3PP板块数据待接入。")
    if kind in ("home", "apr"):
        top_s = max(d["apr"]["stores"], key=lambda s: s["sales"])
        lines.append(f"【APR】月销{fmt_w(apr['sales'])}万/目标{fmt_w(apr['task'])}万/达成{pct(apr['sales_rate'])}%，毛利{fmt_w(apr['gross_profit'])}万（毛利率{pct(apr['gross_rate'])}%）。")
        lines.append(f"客流{int(apr['traffic'])}人，转化率{pct(apr['conv'])}%，客单价{int(apr['avg_ticket'])}元；最佳门店：{top_s['name']}（{fmt_w(top_s['sales'])}万，转化{pct(top_s['conv'])}%）。")
        lines.append(f"90天以上库存{fmt_w(apr['aging90'])}万，残次{fmt_w(apr['defective'])}万，需商务专项关注。")
    if kind in ("home", "apple"):
        lines.append(f"【Apple电商】月销{fmt_w(apple['sales'])}万/目标{fmt_w(apple['task'])}万/达成{pct(apple['sales_rate'])}%，毛利{fmt_w(apple['gross_profit'])}万；京东羽通{fmt_w(d['apple_ec']['stores'][0]['sales'])}万、苏宁啟韬{fmt_w(d['apple_ec']['stores'][1]['sales'])}万。")
        lines.append(f"退款{fmt_w(apple['refund_amt'])}万（退款率{pct(apple['refund_rate'])}%），推广ROI约{d['apple_ec']['stores'][0]['roi']}。")
    if kind in ("home", "shure"):
        lines.append(f"【Shure电商】月销{fmt_w(shure['sales'])}万/目标{fmt_w(shure['task'])}万/达成{pct(shure['sales_rate'])}%，毛利{fmt_w(shure['gross_profit'])}万；内容营销发布{d['shure_ec']['stores'][0]['content_pub'] + d['shure_ec']['stores'][1]['content_pub']}条。")
    if kind in ("home", "inventory"):
        inv = d["inventory"]
        lines.append(f"【库存资金】总库存{fmt_w(inv['total']['amount'])}万（{inv['total']['qty']}件），90天以上{fmt_w(inv['aging_risk_amount'])}万（占{wan(inv['aging_risk_pct'] * 100)}%），360天以上{fmt_w(inv['severe_amount'])}万需专项处理。")
        lines.append(f"覆盖预警{len(inv['cover_warning'])}项：{'、'.join(w['sku'] + '(' + w['store'] + ')' for w in inv['cover_warning'][:3])}。")
    need = [it for it in d["items"] if it.get("need_boss")]
    if need:
        lines.append(f"【需老板决策】{'、'.join(it['title'] + '（' + it.get('decision', '待批复') + '）' for it in need)}。")
    return "\n".join(lines)


def build_ai_answer(q, d):
    s = build_summary("home")
    return f"（本地规则生成）当前看板数据摘要：\n{s}\n\n针对您的问题「{q}」：本演示版基于虚拟数据，具体归因与建议待接入真实数据后由 AI 分析给出。"


def call_ollama(q, d):
    s = build_summary("home")
    prompt = f"你是传天羽经营分析助手。以下为看板数据摘要：\n{s}\n\n老板问题：{q}\n请用中文简洁回答，基于数据，缺失维度说明待接入。"
    body = json.dumps({"model": OLLAMA_MODEL, "prompt": prompt, "stream": False, "think": False}).encode("utf-8")
    req = urllib.request.Request(OLLAMA_URL, data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT) as resp:
        out = json.loads(resp.read().decode("utf-8"))
    return out.get("response", "").strip() or build_ai_answer(q, d)


def json_bytes(v):
    return json.dumps(v, ensure_ascii=False).encode("utf-8")


class Handler(SimpleHTTPRequestHandler):
    server_version = "ChuangelV6/1.0"

    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def send_bytes(self, status, body, ctype):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            self.send_file(BASE / "templates" / "index.html", "text/html; charset=utf-8")
            return
        if path == "/api/data":
            self.send_bytes(200, json_bytes(load_data()), "application/json; charset=utf-8")
            return
        if path == "/api/summary":
            q = parse_qs(urlparse(self.path).query)
            kind = (q.get("kind") or ["home"])[0]
            self.send_bytes(200, json_bytes({"summary": build_summary(kind)}), "application/json; charset=utf-8")
            return
        if path.startswith("/static/"):
            rel = path[len("/static/"):]
            target = (BASE / "static" / rel).resolve()
            root = (BASE / "static").resolve()
            if root in target.parents and target.is_file():
                self.send_file(target)
                return
        self.send_error(404, "Not Found")

    def do_POST(self):
        path = urlparse(self.path).path
        if path != "/api/ai":
            self.send_error(404, "Not Found")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(length).decode("utf-8"))
            q = str(body.get("q", ""))[:500]
        except Exception:
            self.send_bytes(400, json_bytes({"error": "bad request"}), "application/json; charset=utf-8")
            return
        d = load_data()
        try:
            answer = call_ollama(q, d)
        except Exception:
            answer = build_ai_answer(q, d)
        self.send_bytes(200, json_bytes({"answer": answer, "engine": "ollama"}), "application/json; charset=utf-8")

    def send_file(self, path, ctype=None):
        try:
            body = path.read_bytes()
        except OSError:
            self.send_error(404, "Not Found")
            return
        mime = ctype or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        if mime.startswith("text/") and "charset" not in mime:
            mime += "; charset=utf-8"
        self.send_bytes(200, body, mime)


if __name__ == "__main__":
    open_browser = "--no-browser" not in sys.argv
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"传天羽经营看板 V6 -> http://127.0.0.1:{PORT}")
    if open_browser:
        threading = __import__("threading")
        threading.Timer(0.8, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("stopped")
