@echo off
chcp 65001 >nul
cd /d %~dp0
echo 传天羽经营看板 V6 启动中 -> http://127.0.0.1:8003
start http://127.0.0.1:8003
python app.py
