# -*- coding: utf-8 -*-
"""传天羽经营看板 V6 · 虚拟演示数据生成器
老板确认报表结构后的演示数据。所有数值为虚拟演示值，非真实经营数据。
运行: python3 build_virtual_data.py -> data.json
"""
import json

def wan(x):
    return round(x, 1)

# ---------- 列定义（对应报表 sheet 的表头，period 控制日/周/月显隐） ----------
def col(key, label, period, unit="万", fmt="num1", group="销售指标"):
    return {"key": key, "label": label, "period": period, "unit": unit, "fmt": fmt, "group": group}

APR_COLS = [
    col("task", "任务指标", ["month"]),
    col("sales", "销售额", ["day", "week", "month"]),
    col("sales_rate", "指标达成率", ["month"], fmt="pct1"),
    col("sales_per_store", "平均单店产能", ["month"]),
    col("gross_rate", "毛利率", ["day", "week", "month"], fmt="pct1"),
    col("gross_profit", "毛利额", ["day", "week", "month"]),
    col("avg_ticket", "客单价", ["day", "week", "month"], unit="元", fmt="int"),
    col("traffic", "客流", ["day", "week", "month"], unit="人", fmt="int"),
    col("conv", "转化率", ["day", "week", "month"], fmt="pct1"),
    col("conv_cat4", "转化率·四大品类", ["day", "week", "month"], fmt="pct1"),
]
APR_INV = [
    col("inv_total", "库存总额", ["week", "month"]),
    col("inv_turnover", "库存周转", ["week", "month"], unit="天", fmt="int"),
    col("aging90", "90天以上超龄", ["week", "month"]),
    col("defective", "残次", ["week", "month"]),
    col("dead_stock", "不动销", ["week", "month"]),
    col("residual_loss_rate", "残次亏损率", ["week", "month"], fmt="pct1"),
]
APR_ANALYSIS = [
    col("online_ratio", "线上占比", ["day", "week", "month"], fmt="pct1", group="销售分析"),
    col("offline_ratio", "线下占比", ["day", "week", "month"], fmt="pct1", group="销售分析"),
    col("attach_rate", "配件搭售率", ["day", "week", "month"], fmt="pct1", group="销售分析"),
    col("acs_rate", "ACS/AirPods连带率", ["day", "week", "month"], fmt="pct1", group="销售分析"),
    col("struct_host", "销售结构·四大主机", ["day", "week", "month"], group="销售分析"),
    col("struct_pp", "销售结构·1PP/3PP", ["day", "week", "month"], group="销售分析"),
    col("promo_progress", "年货节/音频节任务进度", ["week", "month"], fmt="pct1", group="销售分析"),
    col("traffic_conv", "客流转化", ["day", "week", "month"], fmt="pct1", group="销售分析"),
]
APR_KPI = [
    col("activation_3d", "3D激活率", ["month"], fmt="pct1", group="项目考核"),
    col("compliance", "门店合规分", ["month"], unit="分", fmt="int", group="项目考核"),
    col("o2o_overtime", "O2O线上超时率", ["week", "month"], fmt="pct1", group="项目考核"),
    col("six_services", "六大服务完成率", ["week", "month"], fmt="pct1", group="项目考核"),
    col("carrier_income", "运营商收益", ["month"], group="项目考核"),
    col("dealer_compare", "经销商平均数对比", ["month"], group="项目考核"),
    col("pp_share", "1PP/3PP销售额占比", ["month"], fmt="pct1", group="项目考核"),
    col("model_conv", "四大机型及AirPods转化率", ["month"], fmt="pct1", group="项目考核"),
    col("link_rate", "AirPods/1PP连带率", ["month"], fmt="pct1", group="项目考核"),
    col("subsidy_ratio", "线下国补占比", ["month"], fmt="pct1", group="项目考核"),
    col("labor_rent_rate", "人工/租金费率", ["month"], fmt="pct1", group="项目考核"),
    col("net_rate", "净利率", ["month"], fmt="pct1", group="项目考核"),
]
APR_PROCESS = [
    col("sop_rate", "SOP完成率", ["day", "week", "month"], fmt="pct1", group="其他过程指标"),
    col("revisit", "消费回访数", ["day", "week", "month"], unit="次", fmt="int", group="其他过程指标"),
    col("marketing", "门店宣传/宣发", ["week", "month"], unit="条", fmt="int", group="其他过程指标"),
    col("sample_loss", "样机亏损率", ["month"], fmt="pct1", group="其他过程指标"),
    col("training", "内部培训场次", ["month"], unit="场", fmt="int", group="其他过程指标"),
]
APR_FEES = [
    col("rent", "门店租金", ["month"], group="费用(月度)"),
    col("online_deduction", "线上扣点", ["month"], group="费用(月度)"),
    col("labor", "人工", ["month"], group="费用(月度)"),
    col("logistics", "物流及其他", ["month"], group="费用(月度)"),
    col("capital", "资金占用", ["month"], group="费用(月度)"),
    col("backend", "后台费用", ["month"], group="费用(月度)"),
    col("provision", "滞销残次计提", ["month"], group="费用(月度)"),
    col("property_fee", "物业费", ["month"], group="费用(月度)"),
    col("utilities", "水电费", ["month"], group="费用(月度)"),
    col("amortization", "装修摊销", ["month"], group="费用(月度)"),
    col("rebate_receivable", "返利应收", ["month"], group="费用(月度)"),
    col("rebate_received", "返利已收", ["month"], group="费用(月度)"),
]
APR_PROFIT = [
    col("store_profit", "店铺利润", ["month"], group="利润(月度)"),
    col("op_profit", "营业利润", ["month"], group="利润(月度)"),
]
APR_OTHER = [
    col("store_expansion", "线下拓店进展", ["month"], group="其他"),
    col("private_traffic", "私域流量", ["month"], unit="人", fmt="int", group="其他"),
    col("promotion", "宣传推广", ["month"], unit="条", fmt="int", group="其他"),
]

EC_COLS = [
    col("task", "任务指标", ["month"]),
    col("sales", "销售额", ["day", "week", "month"]),
    col("sales_rate", "指标达成率", ["month"], fmt="pct1"),
    col("gross_rate", "毛利率", ["day", "week", "month"], fmt="pct1"),
    col("gross_profit", "毛利额", ["day", "week", "month"]),
    col("avg_ticket", "客单价", ["day", "week", "month"], unit="元", fmt="int"),
    col("traffic", "流量(进店)", ["day", "week", "month"], unit="人", fmt="int"),
    col("click_rate", "点击率", ["day", "week", "month"], fmt="pct1"),
    col("add_cart", "加购率", ["day", "week", "month"], fmt="pct1"),
    col("conv", "转化率", ["day", "week", "month"], fmt="pct1"),
    col("top_conv", "TOP产品转化率", ["day", "week", "month"], fmt="pct1"),
    col("roi", "推广ROI", ["day", "week", "month"], fmt="num1"),
    col("price_adjust", "调价定价", ["day", "week", "month"], group="流量"),
]
EC_INV = [
    col("inv_total", "库存总额", ["week", "month"]),
    col("inv_turnover", "库存周转", ["week", "month"], unit="天", fmt="int"),
    col("aging90", "90天以上超龄", ["week", "month"]),
    col("residual_loss_rate", "残次亏损率", ["week", "month"], fmt="pct1"),
]
EC_ANALYSIS = [
    col("struct_host", "销售结构·四大主机", ["day", "week", "month"], group="销售分析"),
    col("struct_pp", "销售结构·1PP/3PP", ["day", "week", "month"], group="销售分析"),
    col("pay_conv", "支付转化率", ["day", "week", "month"], fmt="pct1", group="销售分析"),
    col("refund_amt", "退款金额", ["day", "week", "month"], group="销售分析"),
    col("refund_rate", "退款率", ["day", "week", "month"], fmt="pct1", group="销售分析"),
    col("customer_profile", "客户画像", ["day", "week", "month"], group="销售分析"),
    col("compete_rank", "竞店排名", ["week", "month"], group="销售分析"),
    col("compete_share", "竞店规模对比", ["week", "month"], group="销售分析"),
    col("model_mix", "各机型占比分析", ["week", "month"], group="销售分析"),
    col("coupon_effect", "活动推广/补贴券效果", ["week", "month"], group="销售分析"),
    col("compete_visitors", "竞店访客数", ["week", "month"], unit="人", fmt="int", group="销售分析"),
]
EC_KPI = [
    col("activation_3d", "3D激活率", ["month"], fmt="pct1", group="项目考核"),
    col("compliance", "合规检查", ["month"], group="项目考核"),
    col("service_score", "售后及客服评价", ["week", "month"], unit="分", fmt="int", group="项目考核"),
    col("defective_return", "残次退货率", ["week", "month"], fmt="pct1", group="项目考核"),
]
EC_PROCESS = [
    col("revisit", "消费回访数", ["day", "week", "month"], unit="次", fmt="int", group="其他过程指标"),
    col("member_new", "新增会员数", ["week", "month"], unit="人", fmt="int", group="其他过程指标"),
    col("member_stick", "会员黏性", ["month"], group="其他过程指标"),
    col("member_mechanism", "会员机制", ["month"], group="其他过程指标"),
    col("training", "内部培训场次", ["month"], unit="场", fmt="int", group="其他过程指标"),
]
EC_FEES = [
    col("platform_deduction", "平台扣点", ["month"], group="费用(月度)"),
    col("coupon_subsidy", "平台优惠补贴", ["month"], group="费用(月度)"),
    col("promo_fee", "推广费用", ["month"], group="费用(月度)"),
    col("labor", "人工", ["month"], group="费用(月度)"),
    col("logistics", "物流及其他", ["month"], group="费用(月度)"),
    col("capital", "资金占用", ["month"], group="费用(月度)"),
    col("backend", "后台费用", ["month"], group="费用(月度)"),
    col("provision", "滞销残次计提", ["month"], group="费用(月度)"),
    col("service_fee", "平台服务费", ["month"], group="费用(月度)"),
    col("rebate_receivable", "返利应收", ["month"], group="费用(月度)"),
    col("rebate_received", "返利已收", ["month"], group="费用(月度)"),
]
EC_PROFIT = [
    col("store_profit", "店铺利润", ["month"], group="利润(月度)"),
    col("op_profit", "营业利润", ["month"], group="利润(月度)"),
]
EC_OTHER = [
    col("subsidy_receivable", "国补应收进度", ["month"], group="其他"),
    col("mid_platform", "泛中台数据对接", ["month"], group="其他"),
]
SHURE_EXTRA = [
    col("corp_client", "企业客户维护与拓展", ["week", "month"], group="其他过程指标"),
    col("content_pub", "内容营销发布数", ["week", "month"], unit="条", fmt="int", group="其他过程指标"),
    col("content_pv", "内容浏览量", ["week", "month"], unit="次", fmt="int", group="其他过程指标"),
    col("content_conv", "内容转化", ["week", "month"], fmt="pct1", group="其他过程指标"),
    col("dealer_ad", "总代广告费支持", ["month"], group="费用(月度)"),
    col("jd_protect", "京东毛保/消费券", ["month"], group="费用(月度)"),
]

# ---------- 虚拟数据 ----------
apr_stores = [
    {"name": "镇江店", "sales": 486.0, "task": 560.0, "sales_per_store": 486.0, "gross_rate": 0.072,
     "gross_profit": 35.0, "avg_ticket": 6540, "traffic": 6840, "conv": 0.128,
     "online_ratio": 0.18, "offline_ratio": 0.82, "attach_rate": 0.46, "acs_rate": 0.31,
     "struct_host": "iPhone 62% / iPad 15% / Watch 13% / Mac 10%", "struct_pp": "1PP 21% / 3PP 9%",
     "promo_progress": 0.68, "activation_3d": 0.94, "compliance": 96, "o2o_overtime": 0.012,
     "six_services": 0.88, "carrier_income": 6.2, "sop_rate": 0.91, "revisit": 142,
     "marketing": 18, "sample_loss": 0.006, "training": 4, "inv_total": 468.0, "inv_turnover": 31,
     "aging90": 96.0, "defective": 3.2, "dead_stock": 12.0,
     "rent": 26.0, "online_deduction": 4.0, "labor": 31.0, "logistics": 7.5, "capital": 8.0,
     "backend": 5.0, "provision": 4.0, "store_profit": 35.0 - 26.0 - 4.0 - 31.0 - 7.5 - 8.0 - 5.0 - 4.0,
     "op_profit": 35.0 - 26.0 - 4.0 - 31.0 - 7.5 - 8.0 - 5.0 - 4.0,
     "store_expansion": "正常经营·拟扩2个展位", "private_traffic": 3260, "promotion": 12,
     "salespersons": [{"name": "销售员A", "sales": 168.0, "rate": 0.92, "gross": 12.1, "acs": 0.34},
                      {"name": "销售员B", "sales": 152.0, "rate": 0.87, "gross": 10.8, "acs": 0.29},
                      {"name": "销售员C", "sales": 121.0, "rate": 0.78, "gross": 8.6, "acs": 0.25}]},
    {"name": "南京店", "sales": 622.0, "task": 680.0, "sales_per_store": 622.0, "gross_rate": 0.068,
     "gross_profit": 42.3, "avg_ticket": 7120, "traffic": 8120, "conv": 0.119,
     "online_ratio": 0.22, "offline_ratio": 0.78, "attach_rate": 0.42, "acs_rate": 0.28,
     "struct_host": "iPhone 58% / iPad 17% / Watch 15% / Mac 10%", "struct_pp": "1PP 24% / 3PP 8%",
     "promo_progress": 0.72, "activation_3d": 0.96, "compliance": 98, "o2o_overtime": 0.008,
     "six_services": 0.92, "carrier_income": 7.8, "sop_rate": 0.94, "revisit": 186,
     "marketing": 22, "sample_loss": 0.004, "training": 5, "inv_total": 542.0, "inv_turnover": 29,
     "aging90": 88.0, "defective": 2.4, "dead_stock": 10.0,
     "rent": 38.0, "online_deduction": 6.0, "labor": 42.0, "logistics": 9.0, "capital": 10.0,
     "backend": 6.5, "provision": 5.0, "store_profit": 42.3 - 38.0 - 6.0 - 42.0 - 9.0 - 10.0 - 6.5 - 5.0,
     "op_profit": 42.3 - 38.0 - 6.0 - 42.0 - 9.0 - 10.0 - 6.5 - 5.0,
     "store_expansion": "新店筹备中(预计Q4开业)", "private_traffic": 4120, "promotion": 16,
     "salespersons": [{"name": "销售员D", "sales": 208.0, "rate": 0.95, "gross": 14.8, "acs": 0.36},
                      {"name": "销售员E", "sales": 176.0, "rate": 0.89, "gross": 11.9, "acs": 0.31},
                      {"name": "销售员F", "sales": 138.0, "rate": 0.81, "gross": 9.2, "acs": 0.27}]},
    {"name": "苏州店", "sales": 552.0, "task": 600.0, "sales_per_store": 552.0, "gross_rate": 0.070,
     "gross_profit": 38.6, "avg_ticket": 6890, "traffic": 7560, "conv": 0.124,
     "online_ratio": 0.20, "offline_ratio": 0.80, "attach_rate": 0.44, "acs_rate": 0.30,
     "struct_host": "iPhone 60% / iPad 16% / Watch 14% / Mac 10%", "struct_pp": "1PP 22% / 3PP 9%",
     "promo_progress": 0.70, "activation_3d": 0.95, "compliance": 97, "o2o_overtime": 0.010,
     "six_services": 0.90, "carrier_income": 7.0, "sop_rate": 0.92, "revisit": 168,
     "marketing": 20, "sample_loss": 0.005, "training": 4, "inv_total": 505.0, "inv_turnover": 30,
     "aging90": 92.0, "defective": 2.8, "dead_stock": 11.0,
     "rent": 32.0, "online_deduction": 5.0, "labor": 36.0, "logistics": 8.2, "capital": 9.0,
     "backend": 5.8, "provision": 4.5, "store_profit": 38.6 - 32.0 - 5.0 - 36.0 - 8.2 - 9.0 - 5.8 - 4.5,
     "op_profit": 38.6 - 32.0 - 5.0 - 36.0 - 8.2 - 9.0 - 5.8 - 4.5,
     "store_expansion": "正常经营", "private_traffic": 3880, "promotion": 14,
     "salespersons": [{"name": "销售员G", "sales": 190.0, "rate": 0.93, "gross": 13.4, "acs": 0.33},
                      {"name": "销售员H", "sales": 161.0, "rate": 0.86, "gross": 11.0, "acs": 0.28},
                      {"name": "销售员I", "sales": 129.0, "rate": 0.79, "gross": 8.8, "acs": 0.26}]},
    {"name": "无锡店", "sales": 424.0, "task": 500.0, "sales_per_store": 424.0, "gross_rate": 0.066,
     "gross_profit": 28.0, "avg_ticket": 6320, "traffic": 6320, "conv": 0.116,
     "online_ratio": 0.19, "offline_ratio": 0.81, "attach_rate": 0.40, "acs_rate": 0.27,
     "struct_host": "iPhone 61% / iPad 15% / Watch 14% / Mac 10%", "struct_pp": "1PP 20% / 3PP 10%",
     "promo_progress": 0.64, "activation_3d": 0.93, "compliance": 95, "o2o_overtime": 0.014,
     "six_services": 0.85, "carrier_income": 5.6, "sop_rate": 0.89, "revisit": 126,
     "marketing": 15, "sample_loss": 0.007, "training": 3, "inv_total": 428.0, "inv_turnover": 33,
     "aging90": 104.0, "defective": 3.6, "dead_stock": 13.5,
     "rent": 24.0, "online_deduction": 3.5, "labor": 28.0, "logistics": 6.8, "capital": 7.5,
     "backend": 4.5, "provision": 3.8, "store_profit": 28.0 - 24.0 - 3.5 - 28.0 - 6.8 - 7.5 - 4.5 - 3.8,
     "op_profit": 28.0 - 24.0 - 3.5 - 28.0 - 6.8 - 7.5 - 4.5 - 3.8,
     "store_expansion": "正常经营", "private_traffic": 2950, "promotion": 10,
     "salespersons": [{"name": "销售员J", "sales": 146.0, "rate": 0.90, "gross": 9.8, "acs": 0.30},
                      {"name": "销售员K", "sales": 128.0, "rate": 0.83, "gross": 8.2, "acs": 0.26},
                      {"name": "销售员L", "sales": 102.0, "rate": 0.75, "gross": 6.5, "acs": 0.23}]},
    {"name": "常州店", "sales": 336.0, "task": 420.0, "sales_per_store": 336.0, "gross_rate": 0.064,
     "gross_profit": 21.5, "avg_ticket": 6180, "traffic": 5120, "conv": 0.112,
     "online_ratio": 0.17, "offline_ratio": 0.83, "attach_rate": 0.38, "acs_rate": 0.25,
     "struct_host": "iPhone 63% / iPad 14% / Watch 13% / Mac 10%", "struct_pp": "1PP 19% / 3PP 11%",
     "promo_progress": 0.60, "activation_3d": 0.92, "compliance": 94, "o2o_overtime": 0.016,
     "six_services": 0.82, "carrier_income": 4.8, "sop_rate": 0.87, "revisit": 108,
     "marketing": 13, "sample_loss": 0.008, "training": 3, "inv_total": 386.0, "inv_turnover": 35,
     "aging90": 112.0, "defective": 4.1, "dead_stock": 14.8,
     "rent": 20.0, "online_deduction": 3.0, "labor": 24.0, "logistics": 5.6, "capital": 6.5,
     "backend": 4.0, "provision": 3.2, "store_profit": 21.5 - 20.0 - 3.0 - 24.0 - 5.6 - 6.5 - 4.0 - 3.2,
     "op_profit": 21.5 - 20.0 - 3.0 - 24.0 - 5.6 - 6.5 - 4.0 - 3.2,
     "store_expansion": "正常经营", "private_traffic": 2480, "promotion": 9,
     "salespersons": [{"name": "销售员M", "sales": 118.0, "rate": 0.88, "gross": 7.6, "acs": 0.28},
                      {"name": "销售员N", "sales": 104.0, "rate": 0.81, "gross": 6.4, "acs": 0.24},
                      {"name": "销售员O", "sales": 86.0, "rate": 0.73, "gross": 5.2, "acs": 0.21}]},
]
apr_total = {k: sum(s.get(k, 0) or 0 for s in apr_stores) for k in
             ["sales", "task", "gross_profit", "traffic", "revisit", "training",
              "inv_total", "aging90", "defective", "dead_stock", "rent", "labor", "provision"]}
apr_total["sales_rate"] = apr_total["sales"] / apr_total["task"]
apr_total["gross_rate"] = apr_total["gross_profit"] / apr_total["sales"]
apr_total["avg_ticket"] = int(sum(s["avg_ticket"] * s["sales"] for s in apr_stores) / apr_total["sales"])
apr_total["conv"] = sum(s["conv"] * s["traffic"] for s in apr_stores) / apr_total["traffic"]
apr_total["store_profit"] = sum(s["store_profit"] for s in apr_stores)
apr_total["op_profit"] = sum(s["op_profit"] for s in apr_stores)

apple_ec = [
    {"name": "京东羽通", "sales": 702.0, "task": 800.0, "gross_rate": 0.042, "gross_profit": 29.5,
     "avg_ticket": 3260, "traffic": 182000, "click_rate": 0.036, "add_cart": 0.082, "conv": 0.024,
     "roi": 3.8, "inv_total": 420.0, "aging90": 88.0, "refund_amt": 18.6, "refund_rate": 0.031,
     "struct_host": "iPhone 71% / iPad 12% / Watch 11% / Mac 6%", "struct_pp": "1PP 15% / 3PP 8%",
     "compete_rank": "2", "compete_share": "规模约为TOP1的88%", "model_mix": "iPhone16系列占主机62%",
     "coupon_effect": "国补券核销率41%",
     "activation_3d": 0.92, "compliance": "通过", "service_score": 4.6,
     "revisit": 96, "member_new": 428, "member_stick": "月活率56%", "training": 3,
     "platform_deduction": 21.0, "coupon_subsidy": 14.0, "promo_fee": 18.0, "labor": 9.0,
     "logistics": 6.5, "capital": 8.0, "backend": 4.0, "provision": 3.0,
     "store_profit": 29.5 - 21.0 - 14.0 - 18.0 - 9.0 - 6.5 - 8.0 - 4.0 - 3.0,
     "op_profit": 29.5 - 21.0 - 14.0 - 18.0 - 9.0 - 6.5 - 8.0 - 4.0 - 3.0,
     "subsidy_receivable": "国补应收 86万/已回 52万",
     "mid_platform": "进行中",
     "salespersons": [{"name": "运营A", "sales": 262.0, "rate": 0.90, "gross": 10.9, "acs": 0},
                      {"name": "运营B", "sales": 238.0, "rate": 0.86, "gross": 9.7, "acs": 0},
                      {"name": "运营C", "sales": 202.0, "rate": 0.81, "gross": 8.2, "acs": 0}]},
    {"name": "苏宁啟韬", "sales": 406.0, "task": 500.0, "gross_rate": 0.045, "gross_profit": 18.3,
     "avg_ticket": 2980, "traffic": 96000, "click_rate": 0.030, "add_cart": 0.070, "conv": 0.020,
     "roi": 3.2, "inv_total": 260.0, "aging90": 46.0, "refund_amt": 12.2, "refund_rate": 0.038,
     "struct_host": "iPhone 69% / iPad 13% / Watch 12% / Mac 6%", "struct_pp": "1PP 13% / 3PP 9%",
     "compete_rank": "3", "compete_share": "规模约为TOP1的61%", "model_mix": "iPhone16系列占主机58%",
     "coupon_effect": "国补券核销率36%",
     "activation_3d": 0.90, "compliance": "通过", "service_score": 4.4,
     "revisit": 62, "member_new": 312, "member_stick": "月活率48%", "training": 2,
     "platform_deduction": 13.0, "coupon_subsidy": 9.0, "promo_fee": 11.0, "labor": 6.0,
     "logistics": 4.2, "capital": 5.0, "backend": 3.0, "provision": 2.0,
     "store_profit": 18.3 - 13.0 - 9.0 - 11.0 - 6.0 - 4.2 - 5.0 - 3.0 - 2.0,
     "op_profit": 18.3 - 13.0 - 9.0 - 11.0 - 6.0 - 4.2 - 5.0 - 3.0 - 2.0,
     "subsidy_receivable": "国补应收 41万/已回 22万",
     "mid_platform": "待接入",
     "salespersons": [{"name": "运营D", "sales": 156.0, "rate": 0.88, "gross": 7.0, "acs": 0},
                      {"name": "运营E", "sales": 132.0, "rate": 0.82, "gross": 5.8, "acs": 0},
                      {"name": "运营F", "sales": 118.0, "rate": 0.76, "gross": 5.0, "acs": 0}]},
]
apple_total = {k: sum(s.get(k, 0) or 0 for s in apple_ec) for k in
               ["sales", "task", "gross_profit", "traffic", "refund_amt", "inv_total", "aging90"]}
apple_total["sales_rate"] = apple_total["sales"] / apple_total["task"]
apple_total["gross_rate"] = apple_total["gross_profit"] / apple_total["sales"]
apple_total["avg_ticket"] = int(sum(s["avg_ticket"] * s["sales"] for s in apple_ec) / apple_total["sales"])
apple_total["conv"] = sum(s["conv"] * s["traffic"] for s in apple_ec) / apple_total["traffic"]
apple_total["store_profit"] = sum(s["store_profit"] for s in apple_ec)
apple_total["op_profit"] = sum(s["op_profit"] for s in apple_ec)
apple_total["refund_rate"] = apple_total["refund_amt"] / apple_total["sales"] if apple_total["sales"] else 0

shure_ec = [
    {"name": "京东官方旗舰店", "sales": 286.0, "task": 330.0, "gross_rate": 0.052, "gross_profit": 14.9,
     "avg_ticket": 1450, "traffic": 52000, "click_rate": 0.028, "add_cart": 0.065, "conv": 0.018,
     "roi": 3.5, "inv_total": 180.0, "aging90": 38.0, "refund_amt": 6.8, "refund_rate": 0.028,
     "struct_host": "麦克风/耳机/音箱 62% / 其他 38%", "struct_pp": "—",
     "compete_rank": "1", "compete_share": "类目TOP1", "model_mix": "旗舰无线麦占比44%",
     "coupon_effect": "会员券核销率32%",
     "activation_3d": 0, "compliance": "通过", "service_score": 4.8,
     "corp_client": "新增企业客户6家", "content_pub": 24, "content_pv": 86000, "content_conv": 0.014,
     "revisit": 48, "member_new": 226, "member_stick": "月活率52%", "training": 2,
     "platform_deduction": 7.2, "coupon_subsidy": 4.6, "promo_fee": 8.0, "labor": 4.0,
     "logistics": 3.2, "capital": 4.0, "backend": 2.5, "provision": 1.5,
     "dealer_ad": 3.0, "jd_protect": 2.4,
     "store_profit": 14.9 - 7.2 - 4.6 - 8.0 - 4.0 - 3.2 - 4.0 - 2.5 - 1.5 - 3.0 - 2.4,
     "op_profit": 14.9 - 7.2 - 4.6 - 8.0 - 4.0 - 3.2 - 4.0 - 2.5 - 1.5 - 3.0 - 2.4,
     "subsidy_receivable": "—", "mid_platform": "—",
     "salespersons": [{"name": "运营G", "sales": 112.0, "rate": 0.92, "gross": 5.8, "acs": 0},
                      {"name": "运营H", "sales": 96.0, "rate": 0.85, "gross": 4.9, "acs": 0},
                      {"name": "运营I", "sales": 78.0, "rate": 0.78, "gross": 3.9, "acs": 0}]},
    {"name": "天猫官方旗舰店", "sales": 172.0, "task": 210.0, "gross_rate": 0.049, "gross_profit": 8.4,
     "avg_ticket": 1320, "traffic": 38000, "click_rate": 0.025, "add_cart": 0.058, "conv": 0.016,
     "roi": 3.0, "inv_total": 120.0, "aging90": 22.0, "refund_amt": 5.2, "refund_rate": 0.034,
     "struct_host": "麦克风/耳机/音箱 58% / 其他 42%", "struct_pp": "—",
     "compete_rank": "2", "compete_share": "类目TOP2", "model_mix": "旗舰无线麦占比38%",
     "coupon_effect": "会员券核销率28%",
     "activation_3d": 0, "compliance": "通过", "service_score": 4.5,
     "corp_client": "企业客户跟进中4家", "content_pub": 18, "content_pv": 54000, "content_conv": 0.011,
     "revisit": 34, "member_new": 168, "member_stick": "月活率44%", "training": 1,
     "platform_deduction": 4.8, "coupon_subsidy": 3.2, "promo_fee": 5.5, "labor": 3.0,
     "logistics": 2.4, "capital": 3.0, "backend": 2.0, "provision": 1.0,
     "dealer_ad": 2.0, "jd_protect": 0,
     "store_profit": 8.4 - 4.8 - 3.2 - 5.5 - 3.0 - 2.4 - 3.0 - 2.0 - 1.0 - 2.0,
     "op_profit": 8.4 - 4.8 - 3.2 - 5.5 - 3.0 - 2.4 - 3.0 - 2.0 - 1.0 - 2.0,
     "subsidy_receivable": "—", "mid_platform": "—",
     "salespersons": [{"name": "运营J", "sales": 68.0, "rate": 0.90, "gross": 3.3, "acs": 0},
                      {"name": "运营K", "sales": 56.0, "rate": 0.82, "gross": 2.7, "acs": 0},
                      {"name": "运营L", "sales": 48.0, "rate": 0.75, "gross": 2.2, "acs": 0}]},
]
# 演示节奏：月度累计压缩到时间进度附近（虚拟口径，避免预测超标失真）
_SCALE = 0.72
for _s in apr_stores + apple_ec + shure_ec:
    _s["sales"] = round(_s["sales"] * _SCALE, 1)
    _s["gross_profit"] = round(_s["gross_profit"] * _SCALE, 1)
    _s["traffic"] = int(_s["traffic"] * _SCALE)
    if "refund_amt" in _s:
        _s["refund_amt"] = round(_s["refund_amt"] * _SCALE, 1)

# 报表口径补齐：新增字段的演示默认值（缺失字段页面显式显示 —，不静默补数）
_EXTRA = {
    "conv_cat4": 0.115, "top_conv": 0.026, "pay_conv": 0.022, "residual_loss_rate": 0.004,
    "customer_profile": "待接入（平台属性/用户习惯分析）", "compete_visitors": 0,
    "dealer_compare": "待接入（Apple经销商平均数对比）", "net_rate": 0.012,
    "traffic_conv": 0.052, "pp_share": 0.31, "model_conv": 0.24, "link_rate": 0.28,
    "subsidy_ratio": 0.22, "labor_rent_rate": 0.09,
    "price_adjust": "待接入（调价定价记录）", "inv_turnover": 32,
    "defective_return": 0.005, "member_mechanism": "待接入（会员机制）",
    "property_fee": 4.0, "utilities": 1.6, "amortization": 1.2,
    "rebate_receivable": 12.0, "rebate_received": 7.0, "service_fee": 1.5,
}
for _s in apr_stores + apple_ec + shure_ec:
    for _k, _v in _EXTRA.items():
        _s.setdefault(_k, _v)

def _tot(rows, keys):
    return {k: sum((r.get(k) or 0) for r in rows) for k in keys}

apr_total.update(_tot(apr_stores, ["sales", "task", "gross_profit", "traffic", "revisit", "training",
                                   "inv_total", "aging90", "defective", "dead_stock", "rent", "labor", "provision"]))
apple_total.update(_tot(apple_ec, ["sales", "task", "gross_profit", "traffic", "refund_amt", "inv_total", "aging90"]))
shure_total = _tot(shure_ec, ["sales", "task", "gross_profit", "traffic", "refund_amt", "inv_total", "aging90"])
for _t, _rows in ((apr_total, apr_stores), (apple_total, apple_ec), (shure_total, shure_ec)):
    _t["sales_rate"] = _t["sales"] / _t["task"] if _t["task"] else 0
    _t["gross_rate"] = _t["gross_profit"] / _t["sales"] if _t["sales"] else 0
    _t["avg_ticket"] = int(sum(r["avg_ticket"] * r["sales"] for r in _rows) / _t["sales"]) if _t["sales"] else 0
    _t["conv"] = sum(r["conv"] * r["traffic"] for r in _rows) / _t["traffic"] if _t["traffic"] else 0
if apple_total["sales"]:
    apple_total["refund_rate"] = apple_total["refund_amt"] / apple_total["sales"]
if shure_total["sales"]:
    shure_total["refund_rate"] = shure_total["refund_amt"] / shure_total["sales"]

# 演示口径：店铺利润/营业利润用毛利额折算的合理虚拟值（真实口径待财务确认）
for _s in apr_stores:
    _s["store_profit"] = round(_s["gross_profit"] * 0.16, 1)
    _s["op_profit"] = round(_s["gross_profit"] * 0.12, 1)
for _s in apple_ec:
    _s["store_profit"] = round(_s["gross_profit"] * 0.10, 1)
    _s["op_profit"] = round(_s["gross_profit"] * 0.07, 1)
for _s in shure_ec:
    _s["store_profit"] = round(_s["gross_profit"] * 0.11, 1)
    _s["op_profit"] = round(_s["gross_profit"] * 0.08, 1)
# 同步合计中的利润（演示口径）
apr_total["store_profit"] = sum(_s["store_profit"] for _s in apr_stores)
apr_total["op_profit"] = sum(_s["op_profit"] for _s in apr_stores)
apple_total["store_profit"] = sum(_s["store_profit"] for _s in apple_ec)
apple_total["op_profit"] = sum(_s["op_profit"] for _s in apple_ec)
shure_total["store_profit"] = sum(_s["store_profit"] for _s in shure_ec)
shure_total["op_profit"] = sum(_s["op_profit"] for _s in shure_ec)

ppp = {
    "note": "3PP/渠道分销板块为预留框架页。客户×品牌×项目×区域×门店×产品维度，指标：销售/毛利/合同/回款/应收/信用额度/库存/铺货/动销/项目里程碑。数据待接入（商务台账/吉客云3PP）。",
    "status": "预留",
    "customers": []
}

inventory = {
    "total": {"qty": 19467, "amount": 2322.07},
    "category": [
        {"name": "苹果主机", "qty": 4210, "amount": 1486.0, "pct": 0.64},
        {"name": "原装配件", "qty": 8320, "amount": 512.0, "pct": 0.22},
        {"name": "舒尔", "qty": 1240, "amount": 146.0, "pct": 0.063},
        {"name": "第三方配件", "qty": 5697, "amount": 178.07, "pct": 0.077},
    ],
    "warehouse": [
        {"name": "主仓", "qty": 9860, "amount": 1286.0, "pct": 0.554},
        {"name": "门店仓", "qty": 7206, "amount": 846.0, "pct": 0.364},
        {"name": "样机", "qty": 2401, "amount": 190.07, "pct": 0.082},
    ],
    "aging": {"0~30天": 1044.56, "30~90天": 419.07, "90~360天": 620.0, "360天以上": 238.44},
    "aging_risk": [
        {"wh": "主仓", "name": "iPhone 15 Pro 256G", "brand": "苹果", "cat": "主机", "age": "210天", "qty": 86, "amount": 42.8},
        {"wh": "主仓", "name": "iPad 9 64G", "brand": "苹果", "cat": "主机", "age": "180天", "qty": 64, "amount": 22.4},
        {"wh": "门店仓", "name": "AirPods Pro 2", "brand": "苹果", "cat": "配件", "age": "160天", "qty": 210, "amount": 21.0},
        {"wh": "主仓", "name": "MacBook Air M2", "brand": "苹果", "cat": "主机", "age": "200天", "qty": 18, "amount": 18.9},
        {"wh": "门店仓", "name": "舒尔MV7", "brand": "舒尔", "cat": "舒尔", "age": "150天", "qty": 60, "amount": 14.4},
    ],
    "aging_risk_amount": 858.44,
    "aging_risk_pct": 0.37,
    "severe_amount": 120.86,
    "severe_count": 1325,
    "cover_warning": [
        {"sku": "iPhone 16 Pro Max 512G", "need": 24, "now": 6, "store": "常州店", "note": "低于最低库存要求"},
        {"sku": "AirPods Max", "need": 12, "now": 0, "store": "无锡店", "note": "零库存"},
        {"sku": "iPad Air 13寸", "need": 18, "now": 9, "store": "镇江店", "note": "低于最低库存要求"},
    ]
}

items = [
    {"id": "M-001", "board": "APR", "title": "南京新店筹备（Q4开业）", "owner": "渠道发展部", "start": "2026-08-01",
     "due": "2026-10-31", "progress": 0.35, "status": "推进中", "next": "9月中旬确定选址", "need_boss": True,
     "decision": "需老板批复选址与预算"},
    {"id": "M-002", "board": "Apple电商", "title": "国补应收回款跟进", "owner": "财务+电商运营", "start": "2026-07-15",
     "due": "2026-09-30", "progress": 0.6, "status": "推进中", "next": "本月末核对国补台账", "need_boss": False},
    {"id": "M-003", "board": "APR", "title": "六大服务流程SOP落地", "owner": "运营管理部", "start": "2026-08-10",
     "due": "2026-09-15", "progress": 0.7, "status": "推进中", "next": "门店巡店验收", "need_boss": False},
    {"id": "M-004", "board": "库存", "title": "90天以上库存专项去化", "owner": "商务", "start": "2026-08-05",
     "due": "2026-09-30", "progress": 0.25, "status": "滞后", "next": "残次机处理方案", "need_boss": True,
     "decision": "滞销机型是否降价促销需老板拍板"},
]

risks = [
    {"id": "R-001", "level": "高", "type": "库存", "board": "库存", "desc": "90天以上库存858万（占37%），360天+ 120.86万",
     "impact": "资金占用高、跌价风险", "measure": "专项去化、残次计提", "owner": "商务", "due": "2026-09-30",
     "status": "处置中", "close_date": ""},
    {"id": "R-002", "level": "中", "type": "资金", "board": "Apple电商", "desc": "国补应收进度偏慢（已回52/86万）",
     "impact": "现金流与对账风险", "measure": "财务周核对、平台对账", "owner": "财务+电商", "due": "2026-09-30",
     "status": "处置中", "close_date": ""},
    {"id": "R-003", "level": "中", "type": "合规", "board": "APR", "desc": "O2O线上超时率个别门店高于1.5%",
     "impact": "平台服务分扣减", "measure": "门店排班调整", "owner": "运营管理部", "due": "2026-08-31",
     "status": "处置中", "close_date": ""},
    {"id": "R-004", "level": "低", "type": "运营", "board": "Shure电商", "desc": "天猫退款率3.4%略高于均值",
     "impact": "服务评分", "measure": "售后话术与物流优化", "owner": "Shure运营", "due": "2026-08-31",
     "status": "观察", "close_date": ""},
]

company = {
    "task": 4500.0,
    "plates": [
        {"name": "APR门店", "sales": apr_total["sales"], "task": apr_total["task"],
         "sales_rate": apr_total["sales_rate"], "gross_rate": apr_total["gross_rate"],
         "gross_profit": apr_total["gross_profit"], "avg_ticket": apr_total["avg_ticket"],
         "traffic": apr_total["traffic"], "conv": apr_total["conv"],
         "inv_total": apr_total["inv_total"], "fees": apr_total["rent"] + apr_total["labor"] + apr_total["provision"] + 30.0,
         "profit": apr_total["store_profit"]},
        {"name": "Apple电商", "sales": apple_total["sales"], "task": apple_total["task"],
         "sales_rate": apple_total["sales_rate"], "gross_rate": apple_total["gross_rate"],
         "gross_profit": apple_total["gross_profit"], "avg_ticket": apple_total["avg_ticket"],
         "traffic": apple_total["traffic"], "conv": apple_total["conv"],
         "inv_total": apple_total["inv_total"], "fees": 83.5, "profit": apple_total["store_profit"]},
        {"name": "Shure电商", "sales": shure_total["sales"], "task": shure_total["task"],
         "sales_rate": shure_total["sales_rate"], "gross_rate": shure_total["gross_rate"],
         "gross_profit": shure_total["gross_profit"], "avg_ticket": shure_total["avg_ticket"],
         "traffic": shure_total["traffic"], "conv": shure_total["conv"],
         "inv_total": shure_total["inv_total"], "fees": 49.3, "profit": shure_total["store_profit"]},
        {"name": "3PP/渠道分销", "sales": 0, "task": 0, "sales_rate": 0, "gross_rate": 0,
         "gross_profit": 0, "avg_ticket": 0, "traffic": 0, "conv": 0,
         "inv_total": 0, "fees": 0, "profit": 0, "status": "预留"},
    ],
}
company["sales"] = sum(p["sales"] for p in company["plates"])
company["sales_rate"] = company["sales"] / company["task"]
company["gross_profit"] = sum(p["gross_profit"] for p in company["plates"])
company["gross_rate"] = company["gross_profit"] / company["sales"]
company["fees"] = sum(p["fees"] for p in company["plates"])
company["profit"] = sum(p["profit"] for p in company["plates"])
company["time_progress"] = 20 / 31
company["chg_yest"] = 3.2
company["chg_wk"] = 4.8
company["chg_yy"] = 10.6
company["avg_daily"] = company["sales"] / 20
company["today_target"] = 80.0
company["today_achieved"] = company["avg_daily"] / company["today_target"]
company["forecast_month_end"] = company["sales"] / 20 * 31
company["forecast_rate"] = company["forecast_month_end"] / company["task"]
company["gap_pp"] = round((company["sales_rate"] - company["time_progress"]) * 100, 1)

# 演示用环比/同比/派生字段（纯虚拟，结构演示用）
def _pseudo(name, seed=0):
    h = 0
    for ch in name:
        h = (h * 31 + ord(ch)) % 997
    return h

for _idx, _s in enumerate(apr_stores + apple_ec + shure_ec):
    _h = _pseudo(_s["name"] + str(_idx))
    _s["chg_yest"] = round((_h % 240) / 10 - 9.6, 1)   # 较昨日 %
    _s["chg_wk"] = round(((_h // 3) % 260) / 10 - 8.4, 1)   # 较上周 %
    _s["chg_yy"] = round(((_h // 7) % 300) / 10 - 11.0, 1)  # 同比去年 %
    if _s.get("conv"):
        _s["conv_rate_chg"] = round((_h % 40) / 10 - 2.0, 1)  # 转化率变动pp

product_mix = [
    {"name": "iPhone", "sales": 48.2, "pct": 58.4, "chg": 4.1, "yy": 6.2, "margin": 14.2},
    {"name": "iPad", "sales": 11.6, "pct": 14.0, "chg": 2.2, "yy": 8.7, "margin": 8.0},
    {"name": "Mac", "sales": 8.9, "pct": 10.8, "chg": -1.8, "yy": -6.2, "margin": 11.9},
    {"name": "Watch", "sales": 5.4, "pct": 6.5, "chg": 0.9, "yy": 15.4, "margin": 22.1},
    {"name": "音频/配件/服务", "sales": 8.5, "pct": 10.3, "chg": 5.6, "yy": 19.8, "margin": 28.4},
]
product_insight = "结构解读：iPhone 主力 58.4%；Mac 同比 -6.2%（新品切换期）；音频/配件/服务增速最快且毛利最高（28.4%），建议加大连带推荐。"

mgmt_tiles = [
    {"title": "财务 · 集团资金", "lines": ["收 ¥86.2万", "支 ¥71.5万 · 理财 ¥500万"]},
    {"title": "财务 · 应收", "lines": ["电商国补 3笔", "逾期 ¥16.8万"]},
    {"title": "商务 · 库存周转", "lines": ["周转 42天", "覆盖率 92.4%"]},
    {"title": "人事 · 关键岗位", "lines": ["缺编 2人", "出勤率 97%"]},
    {"title": "对账 · 盘点", "lines": ["漏单 0 · 错单 0", "盘点差异 1笔待复核"]},
]

data = {
    "asof": "2026-08-20",
    "period": "month",
    "demo": True,
    "product_mix": product_mix,
    "product_insight": product_insight,
    "mgmt_tiles": mgmt_tiles,
    "meta": {
        "title": "传天羽经营看板 V6",
        "note": "本版为演示版：所有数值均为虚拟演示数据（含门店/店铺名称与销售员），待看板结构与口径确认后接入真实数据。",
        "sources": {
            "sales": "吉客云（待接入真实）", "inventory": "商务库存分析表（虚拟）", "fees": "财务（待接入）",
            "profit": "财务/ERP（待接入）", "ecomm": "电商后台（后期业务使用再接入）", "task": "月度下发（待确认）"
        },
        "period_labels": {"day": "日报口径（当日/今日累计）", "week": "周报口径（含周度字段）", "month": "月报口径（含月度字段）"}
    },
    "company": company,
    "columns": {
        "apr": {"sales": APR_COLS, "inventory": APR_INV, "analysis": APR_ANALYSIS, "kpi": APR_KPI,
                "process": APR_PROCESS, "fees": APR_FEES, "profit": APR_PROFIT, "other": APR_OTHER},
        "apple": {"sales": EC_COLS, "inventory": EC_INV, "analysis": EC_ANALYSIS, "kpi": EC_KPI,
                  "process": EC_PROCESS, "fees": EC_FEES, "profit": EC_PROFIT, "other": EC_OTHER},
        "shure": {"sales": EC_COLS, "inventory": EC_INV, "analysis": EC_ANALYSIS, "kpi": EC_KPI,
                  "process": EC_PROCESS + SHURE_EXTRA[:4], "fees": EC_FEES + SHURE_EXTRA[4:],
                  "profit": EC_PROFIT, "other": EC_OTHER},
    },
    "apr": {"total": apr_total, "stores": apr_stores},
    "apple_ec": {"total": apple_total, "stores": apple_ec},
    "shure_ec": {"total": shure_total, "stores": shure_ec},
    "ppp": ppp,
    "inventory": inventory,
    "items": items,
    "risks": risks,
}

with open("data.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=1)
print("data.json written,", len(json.dumps(data)), "bytes")
print("company sales:", company["sales"], "profit:", round(company["profit"], 1))
