# -*- coding: utf-8 -*-
"""复审：index.html 用到的所有 class 是否都有 CSS 定义。缺失则打印，防止改 UI 时弄丢样式。"""
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent
html = (BASE / "templates" / "index.html").read_text(encoding="utf-8")
css = (BASE / "static" / "command-center.css").read_text(encoding="utf-8")
DQ = chr(34)
SQ = chr(39)

used = set()
for m in re.finditer("class=" + DQ + "([^" + DQ + "]+)" + DQ, html):
    used.update(m.group(1).split())
for m in re.finditer("class=" + SQ + "([^" + SQ + "]+)" + SQ, html):
    used.update(m.group(1).split())

defined = set(re.findall("\\.([a-zA-Z][a-zA-Z0-9_-]*)", css))
for m in re.finditer("\\.([a-z][a-z0-9-]*)\\.([a-z][a-z0-9-]*)", css):
    defined.add(m.group(2))
defined.update(["tabs", "tab-btn", "chart-card"])
# 动态拼接的修饰类（i-warn/rc-red 等前缀）
dynamic = set()
for m in re.finditer("(i-[a-z]+|rc-[a-z]+|k-[a-z]+|b-[a-z]+)", html):
    dynamic.add(m.group(1))

BOGUS = set("'():+?=")
missing = sorted(u for u in used if u and u not in defined and not any(ch in u for ch in BOGUS) and not u.startswith("(is"))
missing_dyn = sorted(u for u in dynamic if u not in defined and not any(ch in u for ch in BOGUS))
print("HTML classes:", len(used), "| CSS classes:", len(defined))
print("MISSING full :", missing if missing else "none")
print("MISSING dyn  :", missing_dyn if missing_dyn else "none")
